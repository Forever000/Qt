/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QTextBrowser *textBrowser;
    QPushButton *addButton;
    QLineEdit *lineEdit;
    QPushButton *pushButton_2;
    QPushButton *addTopButton;
    QPushButton *sortAndShowButton;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(585, 448);
        textBrowser = new QTextBrowser(Widget);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(20, 110, 541, 311));
        addButton = new QPushButton(Widget);
        addButton->setObjectName(QStringLiteral("addButton"));
        addButton->setGeometry(QRect(300, 20, 71, 41));
        lineEdit = new QLineEdit(Widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(20, 20, 261, 41));
        pushButton_2 = new QPushButton(Widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(480, 20, 101, 41));
        addTopButton = new QPushButton(Widget);
        addTopButton->setObjectName(QStringLiteral("addTopButton"));
        addTopButton->setGeometry(QRect(380, 20, 101, 41));
        sortAndShowButton = new QPushButton(Widget);
        sortAndShowButton->setObjectName(QStringLiteral("sortAndShowButton"));
        sortAndShowButton->setGeometry(QRect(480, 60, 101, 41));

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0));
        addButton->setText(QApplication::translate("Widget", "\346\267\273\345\212\240", 0));
        pushButton_2->setText(QApplication::translate("Widget", "\350\276\223\345\207\272\344\272\214\347\273\264\351\223\276\350\241\250", 0));
        addTopButton->setText(QApplication::translate("Widget", "\345\242\236\345\212\240\351\241\266\347\272\247\350\212\202\347\202\271", 0));
        sortAndShowButton->setText(QApplication::translate("Widget", "\346\216\222\345\272\217\345\271\266\350\276\223\345\207\272", 0));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
