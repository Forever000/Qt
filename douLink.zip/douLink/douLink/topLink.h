#ifndef TOPLINK_H
#define TOPLINK_H
#include"cusLink.h"

struct TopNode{
    ListNode* value;
    TopNode* next;
    TopNode(ListNode* val) : value(val), next(nullptr) {}
};



#endif // TOPLINK_H
