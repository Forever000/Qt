#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include"cusLink.h"
#include"topLink.h"
#include<QList>

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

//    cusLink *linkedList;
    ListNode *head;
//    ListNode *linkedList;
    TopNode *topHead;
    void insert(int val);
    void sortLink();
    void customBubbleSort(QList<int>& list);

public slots:
    void addButtonClicked();
    void addTopButtonClicked();
    void sortLink_2();
    void sortAndShow();
private:
    Ui::Widget *ui;
    QList<QList<int>> list2;
};

#endif // WIDGET_H
