#include "widget.h"
#include "ui_widget.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    topHead=nullptr;

    connect(ui->addButton, SIGNAL(clicked()), this, SLOT(addButtonClicked()));
    connect(ui->addTopButton, SIGNAL(clicked()), this, SLOT(addTopButtonClicked()));
    connect(ui->pushButton_2, SIGNAL(clicked()), this, SLOT(sortLink_2()));
    connect(ui->sortAndShowButton, SIGNAL(clicked()), this, SLOT(sortAndShow()));
}

Widget::~Widget()
{
    delete ui;
}

void Widget::addButtonClicked()
{
    QString input = ui->lineEdit->text();
    int value = input.toInt();
    this->insert(value);
    ui->lineEdit->clear();
}

void Widget::insert(int val)
{
    ListNode* newNode = new ListNode(val);
    newNode->next = head;
    head=newNode;
    sortLink();
}

void Widget::addTopButtonClicked()
{
    TopNode *temNode=new TopNode(this->head);
    temNode->next=topHead;
    topHead=temNode;
    this->head=nullptr;
    qDebug()<<"!!!!!!"<<endl;
}

void Widget::sortLink()
{
    //对每个链表进行排序
    if (head == nullptr || head->next == nullptr)
    {
        qDebug()<<"当前链表只有一个节点！"<<endl;
        return;
    }
    bool swapped;
    ListNode* current;
    ListNode* lastSorted = nullptr;

    do {
        swapped = false;
        current = head;

        while (current->next != lastSorted)
        {
            if (current->value > current->next->value)
            {
                int temp = current->value;
                current->value = current->next->value;
                current->next->value = temp;
                swapped = true;
            }
            current = current->next;
        }
        lastSorted = current;
    } while (swapped);
    qDebug()<<"排序完毕！"<<endl;
    for(ListNode* p=this->head;p!=nullptr;p=p->next)
    {
        qDebug().noquote()<<p->value<<"->";
    }
    qDebug()<<endl;
    qDebug()<<"-----------------"<<endl;
}

void Widget::sortLink_2() {
    if (!topHead || !topHead->next) {
        ui->textBrowser->append("TopNode链表为空或只有一个节点，无需排序");
        return;
    }

    TopNode* currentTopNode = topHead;
    TopNode* minTopNode;

    //排序
    while (currentTopNode) {
        minTopNode = currentTopNode;
        TopNode* tempTopNode = currentTopNode->next;

        while (tempTopNode) {
            if (tempTopNode->value->value < minTopNode->value->value) {
                minTopNode = tempTopNode;
            }
            tempTopNode = tempTopNode->next;
        }
        ListNode* tempValue = currentTopNode->value;
        currentTopNode->value = minTopNode->value;
        minTopNode->value = tempValue;

        currentTopNode = currentTopNode->next;
    }
    currentTopNode = topHead;

    //收集链表数据
    QList<QList<int>> curlist;
    while (currentTopNode) {
        QList<int> list1;
        ListNode* currentListNode = currentTopNode->value;

        while (currentListNode) {
            list1.append(currentListNode->value);
            currentListNode = currentListNode->next;
        }
        curlist.append(list1);

        currentTopNode = currentTopNode->next;
    }

    //格式化输出
    this->list2=curlist;
    int numRows = curlist.size();
    int numCols = 0;
    for (int i = 0; i < numRows; ++i) {
        if (curlist[i].size() > numCols) {
            numCols = curlist[i].size();
        }
    }
    QString output;
    for (int j = 0; j < numCols; ++j) {
        bool isFirstInRow = true;

        for (int i = 0; i < numRows; ++i) {
            if (j < curlist[i].size()) {
                if (!isFirstInRow) {
                    output += "\t ";
                }
                output += QString::number(curlist[i][j]);
                isFirstInRow = false;
            } else {
                output += "\t"; // 或者其他占位符
            }

            if (i < numRows - 1)
            {
//                output += "|";
            }
        }
        output += "\n"; // 换行
    }
    ui->textBrowser->setText(output);
}


void Widget::sortAndShow()
{
    //链表中所有数据排序
    QList<int> templist;
    for (int i = 0; i < this->list2.size(); ++i) {
        for (int j = 0; j < this->list2[i].size(); ++j) {
            templist.append(this->list2[i][j]);
        }
    }
    customBubbleSort(templist);
    QString output;

    for (int i = 0; i < templist.size(); ++i) {
        output += QString::number(templist[i]);

        if (i < templist.size() - 1) {
            output += "·->·";
        }
    }
    ui->textBrowser->append(output);
}

void Widget::customBubbleSort(QList<int>& list) {
    int n = list.size();
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - i - 1; ++j) {
            if (list[j] > list[j + 1]) {
                // 交换 list[j] 和 list[j + 1]
                int temp = list[j];
                list[j] = list[j + 1];
                list[j + 1] = temp;
            }
        }
    }
}

