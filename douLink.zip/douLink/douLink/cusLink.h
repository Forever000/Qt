#ifndef CUSLINK_H
#define CUSLINK_H
#include<QDebug>


struct ListNode {
    int value;
    ListNode* next;
    ListNode(int val) : value(val), next(nullptr) {}
};


#endif // CUSLINK_H
